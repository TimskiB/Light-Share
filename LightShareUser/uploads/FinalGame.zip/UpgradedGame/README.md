# **Shoot To Kill**
_A chat app that allows people to chat and play together a 3D first person shooter.
The application was written in Python 3.8 and mainly using the Kivy (KivyMD module and ursina engine._

## **Getting ready**
Install the needed dependencies with `pip install -r requirements.txt`

## **Start using the application**
First, run the server with `python Server/main.py` and then, start connecting clients with `python Client/app.py`.

