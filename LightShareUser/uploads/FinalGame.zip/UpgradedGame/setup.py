from setuptools import setup

setup(
    name='ShootToKill',
    version='1.0',
    packages=[''],
    url='',
    license='',
    install_requires=['kivy', 'kivymd', 'ursina'],
    author='Tim Bolshinsky',
    author_email='timski.school@gmail.com',
    description='My first online game.'
)
